package apotek;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import com.alee.laf.WebLookAndFeel;
import com.alee.laf.button.WebButton;
import com.alee.laf.menu.WebMenu;
import com.alee.laf.menu.WebMenuBar;
import com.alee.laf.menu.WebMenuItem;
import com.alee.laf.toolbar.WebToolBar;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import com.alee.laf.toolbar.ToolbarStyle;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class Gudang extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(new WebLookAndFeel());
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gudang frame = new Gudang();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gudang() {
		setTitle("Gudang");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		WebMenuBar menuBar = new WebMenuBar();
		menuBar.setBounds(0, 0, 885, 21);		
		contentPane.add(menuBar);
		
		WebMenu mnNewMenu = new WebMenu("File");
		menuBar.add(mnNewMenu);
		
		WebMenuItem mntmNewMenuItem = new WebMenuItem("tes");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TambahGudang th = new TambahGudang();
				th.setVisible(true);
			}
		});
		mntmNewMenuItem.setText("Tambah");
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Simpan");
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Exit");
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 69, 885, 494);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 25, 861, 233);
		panel_1.add(scrollPane);
		
		table = new JTable();
		table.setModel(new javax.swing.table.DefaultTableModel(
			    new Object [][] {
			        {null, null, null, null, null},
			        {null, null, null, null, null},
			        {null, null, null, null, null}
			    },
			    new String [] {
			        "Nama Obat", "Persediaan Awal", "Persediaan Masuk", "Total Persediaan", "Tanggal Kadaluarsa"
			    }
			));

			table.setRowHeight(60);

		scrollPane.setViewportView(table);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 22, 885, 51);
		contentPane.add(panel);
		panel.setLayout(null);
		
		WebToolBar toolBar = new WebToolBar();
		toolBar.setRollover(true);
		toolBar.setToolbarStyle(ToolbarStyle.attached);
		toolBar.setBounds(0, 0, 885, 47);
		panel.add(toolBar);
		
		WebButton btnTambah = new WebButton("Tambah");
		btnTambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			TambahGudang th = new TambahGudang();
				th.setVisible(true);
			}
		});
		btnTambah.setTopSelectedBgColor(Color.LIGHT_GRAY);
		btnTambah.setUndecorated(true);
		btnTambah.setIcon(new ImageIcon(Gudang.class.getResource("/image/Add.png")));
		toolBar.add(btnTambah);
		
		JSeparator separator = new JSeparator();
		toolBar.add(separator);
		separator.setForeground(Color.GRAY);
		
		WebButton btnHapus = new WebButton("Hapus");
		btnHapus.setUndecorated(true);
		btnHapus.setIcon(new ImageIcon(Gudang.class.getResource("/image/Delete.png")));
		toolBar.add(btnHapus);
		
		JSeparator separator_1 = new JSeparator();
		toolBar.add(separator_1);
		
		WebButton btnSimpan = new WebButton("Simpan");
		btnSimpan.setUndecorated(true);
		btnSimpan.setIcon(new ImageIcon(Gudang.class.getResource("/image/Save1.png")));
		toolBar.add(btnSimpan);
	}
}
