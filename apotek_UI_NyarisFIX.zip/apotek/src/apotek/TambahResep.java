package apotek;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JScrollBar;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;

public class TambahResep extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			TambahResep dialog = new TambahResep();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public TambahResep() {
		setTitle("Tambah Resep");
		setBounds(100, 100, 825, 468);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
		textField.setBounds(132, 55, 241, 20);
		contentPanel.add(textField);
		textField.setColumns(12);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(10, 183, 380, 2);
		contentPanel.add(separator);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(132, 260, 241, 56);
		contentPanel.add(textArea);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(132, 337, 78, 20);
		contentPanel.add(comboBox);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		textField_1.setBounds(132, 100, 241, 20);
		contentPanel.add(textField_1);
		textField_1.setColumns(12);
		
		textField_2 = new JTextField();
		textField_2.setBounds(132, 219, 241, 20);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(400, 0, 2, 407);
		contentPanel.add(separator_1);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(550, 21, 237, 20);
		contentPanel.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(550, 56, 237, 20);
		contentPanel.add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setBounds(550, 87, 237, 20);
		contentPanel.add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setBounds(550, 118, 237, 20);
		contentPanel.add(comboBox_4);
		
		textField_3 = new JTextField();
		textField_3.setBounds(550, 183, 237, 20);
		contentPanel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(550, 218, 237, 20);
		contentPanel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(550, 249, 237, 20);
		contentPanel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblTanggal = new JLabel("Tanggal :");
		lblTanggal.setBounds(10, 59, 46, 14);
		contentPanel.add(lblTanggal);
		
		JLabel lblWaktu = new JLabel("Waktu :");
		lblWaktu.setBounds(10, 104, 46, 14);
		contentPanel.add(lblWaktu);
		
		JLabel lblNama = new JLabel("Nama :");
		lblNama.setBounds(10, 222, 46, 14);
		contentPanel.add(lblNama);
		
		JLabel lblAlamat = new JLabel("Alamat :");
		lblAlamat.setBounds(10, 260, 46, 14);
		contentPanel.add(lblAlamat);
		
		JLabel lblUmur = new JLabel("Umur");
		lblUmur.setBounds(10, 340, 46, 14);
		contentPanel.add(lblUmur);
		
		JLabel lblJenisLayanan = new JLabel("Jenis Layanan :");
		lblJenisLayanan.setBounds(412, 24, 78, 14);
		contentPanel.add(lblJenisLayanan);
		
		JLabel lblInputObat = new JLabel("Input Obat :");
		lblInputObat.setBounds(412, 59, 78, 14);
		contentPanel.add(lblInputObat);
		
		JLabel lblGolonganObat = new JLabel("Golongan Obat :");
		lblGolonganObat.setBounds(412, 90, 89, 14);
		contentPanel.add(lblGolonganObat);
		
		JLabel lblNamaObat = new JLabel("Nama Obat :");
		lblNamaObat.setBounds(412, 121, 78, 14);
		contentPanel.add(lblNamaObat);
		
		JLabel lblSatuan = new JLabel("Satuan :");
		lblSatuan.setBounds(412, 186, 46, 14);
		contentPanel.add(lblSatuan);
		
		JLabel lblJumlah = new JLabel("Jumlah :");
		lblJumlah.setBounds(412, 218, 46, 14);
		contentPanel.add(lblJumlah);
		
		JLabel lblTanggalKadarluarsa = new JLabel("Tanggal Kadarluarsa :");
		lblTanggalKadarluarsa.setBounds(411, 249, 105, 14);
		contentPanel.add(lblTanggalKadarluarsa);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(550, 280, 237, 77);
		contentPanel.add(textArea_1);
		
		JLabel lblKeterangan = new JLabel("Keterangan :");
		lblKeterangan.setBounds(412, 285, 105, 14);
		contentPanel.add(lblKeterangan);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
