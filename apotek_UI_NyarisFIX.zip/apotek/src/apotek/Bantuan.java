package apotek;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import com.alee.laf.WebLookAndFeel;
import com.alee.laf.button.WebButton;
import com.alee.laf.menu.WebMenu;
import com.alee.laf.menu.WebMenuBar;
import com.alee.laf.menu.WebMenuItem;
import com.alee.laf.toolbar.WebToolBar;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import com.alee.laf.toolbar.ToolbarStyle;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JSeparator;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JList;
import javax.swing.JTree;
import javax.swing.JTextField;

public class Bantuan extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(new WebLookAndFeel());
		} catch (UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bantuan frame = new Bantuan();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bantuan() {
		setTitle("Bantuan");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 891, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 45, 885, 518);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(870, 0, 15, 506);
		panel_1.add(scrollBar);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 260, 518);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JTree tree = new JTree();
		tree.setBounds(0, 0, 192, 518);
		panel_2.add(tree);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 885, 49);
		contentPane.add(panel);
		panel.setLayout(null);
		
		WebToolBar toolBar = new WebToolBar();
		toolBar.setRollover(true);
		toolBar.setToolbarStyle(ToolbarStyle.attached);
		toolBar.setBounds(0, 0, 885, 47);
		panel.add(toolBar);
		
		textField = new JTextField();
		toolBar.add(textField);
		textField.setColumns(10);
		
		WebButton webButtonCari = new WebButton("Simpan");
		webButtonCari.setIcon(new ImageIcon(Bantuan.class.getResource("/image/cari.png")));
		webButtonCari.setText("Cari");
		webButtonCari.setUndecorated(true);
		toolBar.add(webButtonCari);
		
		JSeparator separator = new JSeparator();
		toolBar.add(separator);
		separator.setForeground(Color.GRAY);
		
		JSeparator separator_2 = new JSeparator();
		toolBar.add(separator_2);
		
		WebButton btnZoomIn = new WebButton("Hapus");
		btnZoomIn.setText("Perbesar");
		btnZoomIn.setUndecorated(true);
		btnZoomIn.setIcon(new ImageIcon(Bantuan.class.getResource("/image/zoomIn.png")));
		toolBar.add(btnZoomIn);
		
		JSeparator separator_1 = new JSeparator();
		toolBar.add(separator_1);
		
		WebButton wbtnPerkecil = new WebButton("Hapus");
		wbtnPerkecil.setIcon(new ImageIcon(Bantuan.class.getResource("/image/zoomOut.png")));
		wbtnPerkecil.setUndecorated(true);
		wbtnPerkecil.setText("Perkecil");
		toolBar.add(wbtnPerkecil);
		
		JSeparator separator_3 = new JSeparator();
		toolBar.add(separator_3);
	}
}
