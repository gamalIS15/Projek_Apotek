package apotek;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.JScrollBar;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;

public class TambahGudang extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			TambahGudang dialog = new TambahGudang();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public TambahGudang() {
		setTitle("Tambah Item Gudang");
		setBounds(100, 100, 475, 354);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 12));
		textField.setBounds(161, 81, 241, 20);
		contentPanel.add(textField);
		textField.setColumns(12);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		textField_1.setBounds(161, 112, 241, 20);
		contentPanel.add(textField_1);
		textField_1.setColumns(12);
		
		textField_2 = new JTextField();
		textField_2.setBounds(161, 51, 241, 20);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(161, 147, 241, 20);
		contentPanel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(161, 178, 241, 20);
		contentPanel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(161, 209, 241, 20);
		contentPanel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblGolonganObat = new JLabel("Golongan Obat :");
		lblGolonganObat.setBounds(27, 54, 89, 14);
		contentPanel.add(lblGolonganObat);
		
		JLabel lblNamaObat = new JLabel("Nama Obat :");
		lblNamaObat.setBounds(27, 85, 78, 14);
		contentPanel.add(lblNamaObat);
		
		JLabel lblTanggalKadarluarsa = new JLabel("Tanggal Kadarluarsa :");
		lblTanggalKadarluarsa.setBounds(27, 212, 105, 14);
		contentPanel.add(lblTanggalKadarluarsa);
		
		JLabel lblPersediaanAwal = new JLabel("Persediaan Awal :");
		lblPersediaanAwal.setBounds(27, 115, 105, 14);
		contentPanel.add(lblPersediaanAwal);
		
		JLabel lblPersediaanMasuk = new JLabel("Persediaan Masuk :");
		lblPersediaanMasuk.setBounds(27, 147, 111, 14);
		contentPanel.add(lblPersediaanMasuk);
		
		JLabel lblTotalPersediaan = new JLabel("Total Persediaan :");
		lblTotalPersediaan.setBounds(27, 179, 89, 14);
		contentPanel.add(lblTotalPersediaan);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
