package apotek;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.alee.laf.button.WebButton;
import com.alee.laf.text.WebTextField;

import PanelTransparan.ClPanelTransparan;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;

public class DataObat extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JLabel label;
	private WebTextField textField;
	private JLabel lblPencarianObat;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DataObat frame = new DataObat();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DataObat() {
		setTitle("Data Obat");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 852, 513);
		contentPane = new JPanel();
		contentPane.setForeground(Color.DARK_GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(Color.YELLOW);
		panel.setBounds(0, 0, 836, 474);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 75, 816, 388);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"No", "Satuan", "Golongan", "Nama Obat", "Stok Awal", "Persedian", "Pemakaian", "Sisa Stok", "Saldo Awal", "Jumlah Pemasukan", "Jumlah Penggunaan", "Saldo Akhir", "Keterangan"
			}
		));
		
					table.setRowHeight(45);
					scrollPane.setViewportView(table);
		
		ClPanelTransparan upperPanel = new ClPanelTransparan();
		upperPanel.setBackground(Color.GRAY);
		upperPanel.setBounds(10, 11, 816, 52);
		panel.add(upperPanel);
		upperPanel.setLayout(null);
		
		textField = new WebTextField();
		textField.setToolTipText("Cari Disini");
		textField.setDrawBackground(false);
		textField.setDrawShade(false);
		textField.setBounds(133, 11, 235, 30);
		upperPanel.add(textField);
		textField.setColumns(10);
		
		WebButton button = new WebButton("");
		button.setUndecorated(true);
		button.setIcon(new ImageIcon(DataObat.class.getResource("/image/cari.png")));
		button.setBounds(378, 11, 49, 30);
		upperPanel.add(button);
		
		lblPencarianObat = new JLabel("Pencarian Obat");
		lblPencarianObat.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPencarianObat.setForeground(Color.WHITE);
		lblPencarianObat.setBounds(10, 19, 113, 14);
		upperPanel.add(lblPencarianObat);
		
		label = new JLabel("");
		label.setBounds(0, 0, 836, 474);
		panel.add(label);
		label.setIcon(new ImageIcon(DataObat.class.getResource("/image/wall.png")));
	}
}
